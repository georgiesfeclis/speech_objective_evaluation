function power= pow_of( data, start_point, end_point, divisor)

power= sum( data( start_point: end_point).^ 2)/ divisor; 